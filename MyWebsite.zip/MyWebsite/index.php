<?php

 ?>
 <head>
<title> Document </title>
</head>

<body>

    <h3> sign up <h3>

    <form action="includes/formhandler.inc.php" method="post">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="pwd" placeholder="Password">
        <input type="text" name="email" placeholder="E-Mail">
        <button> Sign up </button>
</form>

</body>
</html>